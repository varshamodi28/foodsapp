from django.shortcuts import render,redirect
from learnapp.forms import UserForm,UserProfileForm,UserUpdateForm
from django.contrib.auth import authenticate,login,logout
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required


# Create your views here.
def registration(request):
    registered = False
    if request.method == 'POST':
        form1  = UserForm(request.POST)
        form2 = UserProfileForm(request.POST,request.FILES)
        if form1.is_valid() and form2.is_valid():
            user = form1.save()
            user.set_password(user.password)
            user.save()

            profile = form2.save(commit=False)
            profile.user = user  #this is connectiong to models to save the final data
            profile.save()
            registered = True

            # print(form1.cleaned_data['username'])
            # print(form2.cleaned_data['address'])
            # print(form1.cleaned_data['password'])
    else:
        form1 = UserForm()
        form2 = UserProfileForm()

    context = {
        'form1':form1,
        'form2':form2,
        'registered':registered
    }
    return render(request,"registration.html",context)



def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(username=username,password=password)
        if user:
            if user.is_active:
                login(request,user)
                return redirect('home')
            else:
                return HttpResponse("user is not active")
        else:
            return HttpResponse("PLS CHECH U R CREDENTIALS")
    return render(request,'login.html',{})

@login_required(login_url='login')
def home(request):
    return render(request,'home.html',{})

@login_required(login_url='login')
def user_logout(request):
    logout(request)
    return redirect('login')

@login_required(login_url='login')
def user_profile(request):
    return render(request,'profile.html')


@login_required(login_url='login')
def user_update(request):
    if request.method == 'POST':
         form = UserUpdateForm(request.POST,instance=request.user)
         if form.is_valid():
             form.save()
             return redirect('profile')
    else:
        form = UserUpdateForm(instance=request.user)
    context ={
        'form':form
            }
    return render(request,'update.html',context)
    







