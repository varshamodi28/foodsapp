from django.contrib import admin
from studentapp.models import STUDENT
# Register your models here.
admin.site.register(STUDENT)
