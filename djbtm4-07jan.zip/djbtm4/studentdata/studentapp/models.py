from django.db import models

# Create your models here.
class STUDENT(models.Model):
    name = models.CharField(max_length=100)
    age = models.PositiveBigIntegerField()
    address = models.CharField(max_length=100)
    phone = models.BigIntegerField()
    marks = models.IntegerField()

    def __str__(self):
        return self.name + " - " + str(self.marks)