from django.db import models

# Create your models here.
class userdetails(models.Model):
    name = models.CharField(max_length=100)
    address = models.CharField(max_length=100)
    comments = models.TextField(max_length=100)
    photo = models.ImageField(upload_to='userimg',blank=True,null=True)