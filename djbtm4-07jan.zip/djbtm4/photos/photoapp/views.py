from django.shortcuts import render,redirect
from photoapp.forms import UserForm
from photoapp.models import userdetails

# Create your views here.
def index(request):
    form = UserForm()
    if request.method == 'POST':
        form = UserForm(request.POST,request.FILES)

        if form.is_valid():
            print("VALIDATION SUCCESFULL")
            form.save()
            return redirect('display')
    return render(request,"index.html",{'form':form})


def display(request):
    userdata = userdetails.objects.all()
    return render(request,'display.html',{'userdata':userdata})

def profile(request):
    return render(request,"profile.html")

def about(request):
    return render(request,"about.html")
