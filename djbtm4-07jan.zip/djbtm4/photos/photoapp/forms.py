from django import forms
from photoapp.models import userdetails

class UserForm(forms.ModelForm):
    class Meta:
        model = userdetails
        fields="__all__"
