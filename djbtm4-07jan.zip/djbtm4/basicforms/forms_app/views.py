from django.shortcuts import render
from forms_app.forms import StudentForm

# Create your views here.
def index(request):
    form=StudentForm()
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid:
            print("DATA VALIDATION  SUCCESS")
            form.save()
    return render(request,'index.html',{'form':form})
