from django import forms
# from forms_app.models import *
from forms_app.models import Student

class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = '__all__'

# class StudentForm(forms.form):       
    # name = forms.CharField(max_length=100)
    # age = forms.IntegerField()
    # phone = forms.IntegerField()
    # address = forms.CharField(max_length=100)
    # marks = forms.IntegerField()

    # def clean_name(self):

    #     name = self.cleaned_data['name']
    #     if ord(name[0]) >= 48 and ord(name[0]) <= 57:
    #         raise forms.ValidationError('name should start with character not number')
    #     return name

    # def clean_age(self):

    #     age = self.cleaned_data['age']
    #     if age <= 0:
    #         raise forms.ValidationError('age must be only postive')
    #     return age 
    
    # def clean_phone(self):
        
    #     phone = self.cleaned_data['phone']
    #     if len(str(phone)) > 10 or len(str(phone)) < 10 :
    #         raise forms.ValidationError('number must be excatly 10 digit')
    #     return phone