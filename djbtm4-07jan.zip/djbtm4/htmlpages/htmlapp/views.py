from django.shortcuts import render

# Create your views here.
def index(request):
    details = {
        'name' : 'Python',
        'cities':['Bangalore','Mysore','Hasan','kochi',"chennai",'Mumbai'],
        'mobiles':(
            {'model':'galaxy s25','color':'black','price':125000,'company':'samsung','rating':8.5},
            {'model':'vivo s2','color':'silver','price':12500,'company':'vivo','rating':8.9},
            {'model':'mi','color':'light blue','price':12300,'company':'mi','rating':8.3},
            {'model':'galaxy s30','color':'blue','price':125340,'company':'samsung','rating':8.2},
            {'model':'oppo s50','color':'white','price':12500,'company':'oppo','rating':8.1},
            {'model':'galaxy ultra','color':'black','price':155000,'company':'samsung','rating':9.6}
        )
    }
    # return render(request,"index.html",{'name':"Gopi"})
    return render(request,"index.html",context=details)


def contact(request):
    return render(request,"contact.html")

def result(request):
    # n1 = int(request.GET['num1'])
    # n2 = int(request.GET['num2'])
    n1 = int(request.POST['num1'])
    n2 = int(request.POST['num2'])
    if 'add' in request.POST:
        res = n1+n2
    elif 'sub' in request.POST:
        res= n1-n2
    elif 'mul' in request.POST:
        res= n1*n2
    elif 'div' in request.POST:
        res= n1//n2
    elif 'mod' in request.POST:
        res= n1%n2
    # res = n1%n2
    return render(request,"result.html",{'res':res})

def about(request):
    return render(request,"about.html")

def dashboard(request):
    return render(request,"dashboard.html")
