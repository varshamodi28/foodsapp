from django.urls import path
from htmlapp import views

urlpatterns = [
    path('',views.index),
    path('contact',views.contact),
    path('about',views.about),
    path('result',views.result),
    path('dashboard',views.dashboard),

]